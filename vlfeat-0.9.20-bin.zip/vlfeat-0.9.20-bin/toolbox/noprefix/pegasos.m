function varargout = pegasos(varargin)
% VL_PEGASOS [deprecated]
% VL_PEGASOS is deprecated. Please use VL_SVMTRAIN() instead.
[varargout{1:nargout}] = vl_pegasos(varargin{:});
